﻿using System;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Windows;
using LauncherSettings;

namespace Kingston_RolePlay
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            SettingsText();

        }
        void SettingsText()
        {
            TextGamesProgress.Content = TextLauncher.ProgressText;
        }
        void FilesFind()
        {
            var dir = AppDomain.CurrentDomain.BaseDirectory;
            var ConfigFiles = Path.Combine(dir, (string)ModuleLauncher.ConfigPath);
            var ASIFiles = Path.Combine(dir, (string)ModuleLauncher.ASIPath);
            var SAMPFiles = Path.Combine(dir, (string)ModuleLauncher.SAMPPath);
            var GTAFiles = Path.Combine(dir, (string)ModuleLauncher.GTAPath);
            var CEFFiles = Path.Combine(dir, (string)ModuleLauncher.CEFPath);

            if (UpdateParams.FilesGame == 0)
            {
                if (File.Exists(ASIFiles) || File.Exists(SAMPFiles) || File.Exists(GTAFiles) || File.Exists(CEFFiles))
                {
                    UpdateParams.SystemFiles = 1;
                    UpdateParams.FilesGame = 1;
                }
                else UpdateParams.SystemFiles = 0; UpdateParams.FilesGame = 0;
                if (UpdateParams.SystemFiles == 0)
                {
                    MessageBox.Show((string)TextLauncher.ErrorGamesFiles);

                }
            }
            if (File.Exists(ConfigFiles))
            {
                UpdateParams.FilesConfig = 1;
            }
            else UpdateParams.FilesConfig = 0;
            if (UpdateParams.FilesConfig == 0)
            {
                MessageBox.Show((string)TextLauncher.ErrorConfig);
            }
        }
        void Download()
        {
            FilesFind();
            var dir = AppDomain.CurrentDomain.BaseDirectory;
            var ArchiveName = Path.Combine(dir, (string)ModuleLauncher.Archive);
            var ConfigFiles = Path.Combine(dir, (string)ModuleLauncher.ConfigPath);
            var ConfigUnPacking = Path.Combine(dir, (string)ModuleLauncher.ConfigUnPacking);
            // обработчик ошибок ( ex.message ) 
            if (UpdateParams.FilesGame == 0)
            {


                try
                {

                    //загрузка игры
                    using (WebClient client = new WebClient())
                    {
                        Uri uri_files = new Uri((string)UrlSettings.UrlFiles);
                        client.DownloadFileAsync(uri_files, ArchiveName);
                        client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
                        client.DownloadFileCompleted += new System.ComponentModel.AsyncCompletedEventHandler(client_DownloadFileCompleted);
                        void client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
                        {
                            //когда идет загрузка
                            TextGamesProgress.Content = TextLauncher.StatusDownload;
                            progress.Value = e.ProgressPercentage;


                        }
                        void client_DownloadFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
                        {
                            //конец загрузки
                            UpdateParams.FilesGame = 1;
                            ZipFile.ExtractToDirectory(ArchiveName, ConfigUnPacking);
                            System.IO.File.Delete(ArchiveName);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else start_game(); //MessageBox.Show((string)TextLauncher.ErrorGames);
        }
        void start_game()
        {
            try
            {
                if(text1.Text == "") { MessageBox.Show((string)TextLauncher.ErrorNickName); }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /*void FilesZip(string file, string path)
        {

        }*/
        void FilesWrite(string file, string text)
        {
            using (FileStream fstream = new FileStream(file, FileMode.OpenOrCreate))
            {
                byte[] array = System.Text.Encoding.Default.GetBytes(text);
                fstream.Write(array, 0, array.Length);
            }
        }
        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            //settings
        }
        private void MouseLeftButton(object sender, System.Windows.Input.MouseButtonEventArgs e) { this.DragMove(); }
        private void Close_Click(object sender, RoutedEventArgs e) 
        { 
            if(File.Exists((string)ModuleLauncher.Archive))
            {
                File.Delete((string)ModuleLauncher.Archive);
                MessageBox.Show("Files Path delete! Cache : null", "Debug");
            }
            this.Close(); 
        }
        private void Ar_Click(object sender, RoutedEventArgs e){ this.WindowState = WindowState.Minimized; }

        private void GamesStart_Click(object sender, RoutedEventArgs e) 
        {
            Download();
            var dir = AppDomain.CurrentDomain.BaseDirectory;
            var ConfigFiles = Path.Combine(dir, (string)ModuleLauncher.ConfigPath);
            FilesWrite(ConfigFiles, text1.Text);
        }
        
    }
}
