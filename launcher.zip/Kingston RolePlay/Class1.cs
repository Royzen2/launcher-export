﻿namespace LauncherSettings
{
    class TextLauncher
    {
        public static object ErrorConfig = "У вас не найден системный Config файл \n" +
            "Зайдите настройки и нажмите проверить лаунчер.";
        public static object ProgressText = "Нажмите 'Играть' чтобы проверить игру";
        public static object ErrorGamesFiles = "У вас не найдены файлы игры\n" +
            "Зайдите в настройки и нажмите проверить игру";
        public static object StatusDownload = "Идет загрузка компонентов игры";
        public static object ErrorGames = "Игра уже загружена!";
        public static object ErrorNickName = "Укажите NickName!";
    }
    class ModuleLauncher
    {
        public static object ConfigPath = "config.ini"; //запись настроек
        public static object ConfigUnPacking = "bin/KingstonGames/"; //куда будет распаковка
        public static object ConfigPacking = "KingstonGames"; //archive
        public static object ASIPath = "bin/KingstonGames/KingstonGame.asi";
        public static object SAMPPath = "bin/KingstonGames/samp.dll";
        public static object GTAPath = "bin/KingstonGames/gta_sa.exe";
        public static object CEFPath = "bin/KingstonGames/cef.asi";
        public static object Archive = "KingstonGames.zip";

    }
    class UrlSettings
    {
        public static object UrlFiles = "http://212.109.193.79/kingston/cef.zip"; //212.109.193.79/kingston/game_files.zip
    }
    class UpdateParams
    {
        public static short FilesConfig = 0; //STANDART
        public static short SystemFiles = 0; //standart
        public static short FilesGame = 0;
        public static short Version = 0; //версия лаунчера
        public static short ServerVersion = 0; //версия сервера ( VDS )
        public static object ServerName = ""; //название сервера 
        
     
    }
    class UpdateServerInfo
    {
        public static object IP = null;
        public static short Port = 7777;


        // no edit ( pls )
        public static object ConnectTimeAPI = 1.5;
        public static object ConnectAPIServerSampRegistration = 5.1;
        public static object ConnectServerSampRegistration = 5.4;
        public static object ConnectServerSampIntraver = 1;
        public static object SampKeyAPI = "vCzt25%VU26b9ae76c39a24f1424045e2be3511ff1686f1140b890ab426a5ed1badb77adb00fff81a6864fb7d9ea0eed608f7db6a94c27cbbb2b28c0fc73a023ce89d1a4e9f";
    }
}
